BTC AI EA V7 upload

Upload ONLY backtest.py to the repository root, replacing the existing file.
Do not change .github/workflows/backtest.yml.

V7 design:
- keeps V5.1-derived Core + Tactical long return engine
- removes progressive account-drawdown sizing
- proactive 20/50/200D trend + momentum + 20D-high drawdown + volatility risk states
- immediate risk escalation, delayed/hysteretic recovery
- 15% hard stop remains a separate research gate
