BTC AI EA V7.2 업로드 안내

1) 이 압축파일을 풉니다.
2) GitHub kimbeomcheon/btc-ai-ea 저장소 루트에서 기존 backtest.py를 이 파일로 교체합니다.
3) requirements.txt와 .github/workflows/backtest.yml은 수정하지 않습니다.
4) main 브랜치에 Commit changes 하면 GitHub Actions가 자동 실행됩니다.

V7.2 핵심
- V7.1D_STICKY 수익/시장위험 엔진 고정
- 30일 실현변동성 + 90일 중앙값 대비 변동성 확장으로 별도 Volatility Budget 구성
- NORMAL / WARN / HIGH 3단계
- 위험 상승 즉시 축소, 회복은 지연(hysteresis)
- HIGH에서는 Tactical 신규 진입 억제 및 기존 Tactical 축소
- V7.2 후보들은 오직 volatility-budget 기준/축소율만 다르게 하여 새 레이어 효과를 분리 검증
- 선택 전략 대비 'volatility budget 비활성화' attribution 별도 출력
- robustness_grid는 budget threshold ±20% 성격 + exposure ±20% 조합 검증
- 개발 목표 CAGR 20% 이상 / MDD 15% 이하를 추가로 표시하되, 기존 최종 25% CAGR 게이트는 유지

주의: 실제 전체 BTC 백테스트 결과는 GitHub Actions 실행 후 판단합니다.
